import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class BookingService {

  url1 = 'http://localhost:4000/bookingdetails'
  url2 = 'http://localhost:4000/roomcategory'
  url3 = 'http://localhost:4000/bedding'
  url4 = 'http://localhost:4000/user'

  constructor(private http: HttpClient) { }

  booking(name='', email='', phone_number='', check_in='', check_out='', num_guest='', type_room='', special_request='',booking_id=2 ) {
    const body = {
     name:name,
     email:email,
     phone_number:phone_number,
     check_in:check_in,
     check_out:check_out,
     num_guest:num_guest,
     type_room:type_room,
     special_request:special_request
    }

    return this.http.post(this.url1 + '/book', body)
  }

  getRoomCategory() {
    return this.http.get(this.url2)
  }

  getBeddingCategory() {
    return this.http.get(this.url3)
  }
  getId(){
    return this.http.get(this.url1 + '/id')
  }
}